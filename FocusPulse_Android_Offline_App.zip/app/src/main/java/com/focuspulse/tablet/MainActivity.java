package com.focuspulse.tablet;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.focuspulse.tablet.data.FocusDatabaseHelper;
import com.focuspulse.tablet.data.FocusDatabaseHelper.CircledQuestion;
import com.focuspulse.tablet.data.FocusDatabaseHelper.QuestionLog;
import com.focuspulse.tablet.data.FocusDatabaseHelper.TopicGoal;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

public class MainActivity extends Activity {

    private FocusDatabaseHelper db;
    private ToneGenerator toneGen;
    private final Handler tickHandler = new Handler(Looper.getMainLooper());

    // Theme Palette (0 = Obsidian Dark, 1 = AMOLED Black, 2 = Paper Light)
    private int themeIndex = 0;
    private int colBg = Color.parseColor("#0D0F14");
    private int colSurface = Color.parseColor("#151922");
    private int colSub = Color.parseColor("#1C2230");
    private int colInk = Color.parseColor("#F2F4F8");
    private int colMute = Color.parseColor("#8690A6");
    private int colLine = Color.parseColor("#262D40");
    private int colAcc = Color.parseColor("#6384FF");
    private int colOk = Color.parseColor("#38D996");
    private int colWarn = Color.parseColor("#FFAE42");
    private int colBad = Color.parseColor("#FF6370");

    // Navigation & Active Session State
    private String currentTab = "studio"; // studio, review, stats, topics, settings
    private String selectedSubject = "Mathematics";
    private String currentTopic = "";
    private String studyMode = "learn"; // learn, test
    private String coachTone = "mix";   // off, kind, mix, roast
    private int sessionGoal = 20;
    private int topicGoal = 100;
    private int targetSeconds = 180;

    // Monotonic Clock Timer State (Zero background / screen-lock time loss)
    private boolean sessionActive = false;
    private boolean timerRunning = false;
    private long accumulatedMs = 0L;
    private long lastResumeRealtimeMs = 0L;
    private int displaySeconds = 0;
    private int questionNum = 1;
    private int sessionDoneCount = 0;
    private int extAlmost = 0;
    private int extLookup = 0;
    private String selectedErrorTag = "";
    private String currentNote = "";
    private boolean beepedCurrent = false;
    private int goodStreak = 0;
    private int badStreak = 0;
    private String coachMessage = "Ready to lock in. First question sets the tone.";
    private final List<QuestionLog> undoHistory = new ArrayList<>();

    // Dynamic UI References for fast 200ms timer ticks
    private FrameLayout rootContainer;
    private RingTimerView ringTimerView;
    private TextView clockReadoutText;
    private TextView clockSubtitleText;
    private TextView coachBannerView;
    private Button pauseResumeButton;
    private EditText liveNoteInput;

    private final Runnable timerRunnable = new Runnable() {
        @Override
        public void run() {
            if (sessionActive && timerRunning) {
                long now = SystemClock.elapsedRealtime();
                long totalMs = accumulatedMs + (now - lastResumeRealtimeMs);
                displaySeconds = (int) (totalMs / 1000L);
                int limit = getCurrentLimitSeconds();
                if ("learn".equals(studyMode) && !beepedCurrent && displaySeconds >= limit) {
                    beepedCurrent = true;
                    playAlertTone(false);
                    coachMessage = "⏰ Target time reached! Push +2m solo or check the hint.";
                    if (coachBannerView != null) coachBannerView.setText(coachMessage);
                }
                updateLiveClockWidgets();
            }
            tickHandler.postDelayed(this, 200L);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        db = new FocusDatabaseHelper(this);
        List<String> subs = db.getSubjects();
        if (!subs.isEmpty()) selectedSubject = subs.get(0);

        try {
            toneGen = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 85);
        } catch (Exception ignored) {}

        rootContainer = new FrameLayout(this);
        setContentView(rootContainer);
        applyThemePalette();
        rebuildScreen();
        tickHandler.post(timerRunnable);
    }

    @Override
    protected void onDestroy() {
        tickHandler.removeCallbacksAndMessages(null);
        if (toneGen != null) {
            toneGen.release();
        }
        super.onDestroy();
    }

    private void applyThemePalette() {
        if (themeIndex == 0) { // Obsidian Dark
            colBg = Color.parseColor("#0D0F14");
            colSurface = Color.parseColor("#151922");
            colSub = Color.parseColor("#1C2230");
            colInk = Color.parseColor("#F2F4F8");
            colMute = Color.parseColor("#8690A6");
            colLine = Color.parseColor("#262D40");
            colAcc = Color.parseColor("#6384FF");
        } else if (themeIndex == 1) { // AMOLED Pitch Black
            colBg = Color.parseColor("#000000");
            colSurface = Color.parseColor("#0A0C10");
            colSub = Color.parseColor("#12161F");
            colInk = Color.parseColor("#FFFFFF");
            colMute = Color.parseColor("#7A8499");
            colLine = Color.parseColor("#1E2330");
            colAcc = Color.parseColor("#7091FF");
        } else { // Paper Light
            colBg = Color.parseColor("#F4F3EF");
            colSurface = Color.parseColor("#FFFFFF");
            colSub = Color.parseColor("#EAE8E1");
            colInk = Color.parseColor("#15171C");
            colMute = Color.parseColor("#6E7380");
            colLine = Color.parseColor("#DCD9D0");
            colAcc = Color.parseColor("#3B63F6");
        }
        rootContainer.setBackgroundColor(colBg);
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private GradientDrawable roundedBox(int fillColor, int strokeColor, int radiusDp) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(fillColor);
        gd.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) {
            gd.setStroke(dp(1), strokeColor);
        }
        return gd;
    }

    private void playAlertTone(boolean isGoal) {
        if (toneGen == null) return;
        try {
            toneGen.startTone(isGoal ? ToneGenerator.TONE_PROP_ACK : ToneGenerator.TONE_PROP_BEEP2, 240);
        } catch (Exception ignored) {}
    }

    private int getCurrentLimitSeconds() {
        return targetSeconds + 120 * (extAlmost + extLookup);
    }

    public static String formatSec(int sec) {
        int s = Math.max(0, sec);
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60);
    }

    private void updateLiveClockWidgets() {
        if (clockReadoutText == null || ringTimerView == null || clockSubtitleText == null) return;
        int limit = getCurrentLimitSeconds();
        if ("learn".equals(studyMode)) {
            int rem = limit - displaySeconds;
            boolean over = rem < 0;
            clockReadoutText.setText((over ? "+" : "") + formatSec(Math.abs(rem)));
            clockReadoutText.setTextColor(over ? colBad : (rem <= 30 ? colWarn : colInk));
            float ratio = Math.min(1f, (float) displaySeconds / Math.max(1, limit));
            ringTimerView.setProgress(ratio, over ? colBad : (rem <= 30 ? colWarn : colAcc));
            clockSubtitleText.setText(over
                    ? ("Over target by " + formatSec(Math.abs(rem)))
                    : ("Target: " + formatSec(limit)));
        } else {
            boolean over = displaySeconds > targetSeconds;
            clockReadoutText.setText(formatSec(displaySeconds));
            clockReadoutText.setTextColor(over ? colBad : colInk);
            float ratio = Math.min(1f, (float) displaySeconds / Math.max(1, targetSeconds));
            ringTimerView.setProgress(ratio, over ? colBad : colAcc);
            clockSubtitleText.setText("Exam Stopwatch · Reference Pace: " + formatSec(targetSeconds));
        }
    }

    private void rebuildScreen() {
        rootContainer.removeAllViews();

        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.HORIZONTAL);
        shell.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Left Navigation Rail for Tablet Ergonomics
        LinearLayout navRail = new LinearLayout(this);
        navRail.setOrientation(LinearLayout.VERTICAL);
        navRail.setGravity(Gravity.CENTER_HORIZONTAL);
        navRail.setPadding(dp(10), dp(18), dp(10), dp(18));
        navRail.setBackgroundColor(colSurface);
        LinearLayout.LayoutParams railLp = new LinearLayout.LayoutParams(dp(96), ViewGroup.LayoutParams.MATCH_PARENT);
        shell.addView(navRail, railLp);

        TextView logo = new TextView(this);
        logo.setText("FP");
        logo.setTextColor(colAcc);
        logo.setTextSize(18);
        logo.setTypeface(Typeface.DEFAULT_BOLD);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(roundedBox(colSub, colAcc, 14));
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(50), dp(50));
        logoLp.bottomMargin = dp(18);
        navRail.addView(logo, logoLp);

        int circledCount = db.getCircledQueue().size();
        addNavButton(navRail, "studio", "⏱\nTimer");
        addNavButton(navRail, "review", "📌\nReview" + (circledCount > 0 ? " (" + circledCount + ")" : ""));
        addNavButton(navRail, "stats", "📊\nStats");
        addNavButton(navRail, "topics", "📚\nSubjects");
        addNavButton(navRail, "settings", "⚙\nData");

        // Right Main Stage
        LinearLayout stage = new LinearLayout(this);
        stage.setOrientation(LinearLayout.VERTICAL);
        stage.setLayoutParams(new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        shell.addView(stage);

        // Top Header Bar
        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(22), dp(14), dp(22), dp(14));
        topBar.setBackgroundColor(colSurface);
        stage.addView(topBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView titleView = new TextView(this);
        titleView.setText("FocusPulse Tablet Studio");
        titleView.setTextColor(colInk);
        titleView.setTextSize(19);
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        topBar.addView(titleView, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView wakePill = new TextView(this);
        wakePill.setText("🟢 Screen Awake");
        wakePill.setTextColor(colOk);
        wakePill.setTextSize(12);
        wakePill.setPadding(dp(12), dp(6), dp(12), dp(6));
        wakePill.setBackground(roundedBox(colSub, colLine, 20));
        LinearLayout.LayoutParams wpLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        wpLp.rightMargin = dp(10);
        topBar.addView(wakePill, wpLp);

        String[] themeNames = new String[]{"Theme: Dark", "Theme: AMOLED", "Theme: Light"};
        Button themeBtn = makeActionButton(themeNames[themeIndex], colSub, colInk);
        themeBtn.setOnClickListener(v -> {
            themeIndex = (themeIndex + 1) % 3;
            applyThemePalette();
            rebuildScreen();
        });
        topBar.addView(themeBtn);

        // Content Scroll Area
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        stage.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(18), dp(20), dp(28));
        scroll.addView(content);

        if ("studio".equals(currentTab)) {
            buildStudioView(content);
        } else if ("review".equals(currentTab)) {
            buildReviewView(content);
        } else if ("stats".equals(currentTab)) {
            buildStatsView(content);
        } else if ("topics".equals(currentTab)) {
            buildTopicsView(content);
        } else {
            buildSettingsView(content);
        }

        rootContainer.addView(shell);
    }

    private void addNavButton(LinearLayout rail, final String tabKey, String label) {
        boolean active = tabKey.equals(currentTab);
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextSize(11);
        b.setTextColor(active ? colAcc : colMute);
        b.setBackground(roundedBox(active ? colSub : Color.TRANSPARENT, active ? colAcc : 0, 14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(64));
        lp.bottomMargin = dp(8);
        b.setOnClickListener(v -> {
            if (sessionActive && liveNoteInput != null) {
                currentNote = liveNoteInput.getText().toString();
            }
            currentTab = tabKey;
            rebuildScreen();
        });
        rail.addView(b, lp);
    }

    private Button makeActionButton(String text, int bg, int fg) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(text);
        b.setTextColor(fg);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setPadding(dp(14), dp(10), dp(14), dp(10));
        b.setBackground(roundedBox(bg, colLine, 13));
        return b;
    }

    private void buildStudioView(LinearLayout parent) {
        LinearLayout splitRow = new LinearLayout(this);
        splitRow.setOrientation(LinearLayout.HORIZONTAL);
        parent.addView(splitRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // Left Pane: Setup or Active Circular Timer
        LinearLayout leftCard = new LinearLayout(this);
        leftCard.setOrientation(LinearLayout.VERTICAL);
        leftCard.setPadding(dp(22), dp(22), dp(22), dp(22));
        leftCard.setBackground(roundedBox(colSurface, colLine, 20));
        LinearLayout.LayoutParams leftLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.35f);
        leftLp.rightMargin = dp(16);
        splitRow.addView(leftCard, leftLp);

        if (!sessionActive) {
            buildSetupCard(leftCard);
        } else {
            buildLiveTimerCard(leftCard);
        }

        // Right Pane: Circled to Revisit Tray + Live Session Log
        LinearLayout rightCol = new LinearLayout(this);
        rightCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams rightLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        splitRow.addView(rightCol, rightLp);

        // Circled Queue Card
        LinearLayout circledCard = new LinearLayout(this);
        circledCard.setOrientation(LinearLayout.VERTICAL);
        circledCard.setPadding(dp(18), dp(18), dp(18), dp(18));
        circledCard.setBackground(roundedBox(colSurface, colLine, 20));
        LinearLayout.LayoutParams ccLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ccLp.bottomMargin = dp(16);
        rightCol.addView(circledCard, ccLp);

        List<CircledQuestion> circledList = db.getCircledQueue();
        addSectionHeader(circledCard, "Circled to Revisit (" + circledList.size() + ")");
        if (circledList.isEmpty()) {
            addMutedText(circledCard, "Questions you circle during Practice or Exam mode stay here with their timer saved so you can resume them anytime.");
        } else {
            for (final CircledQuestion cq : circledList) {
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(12), dp(10), dp(12), dp(10));
                row.setBackground(roundedBox(colSub, colLine, 12));
                LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                rlp.topMargin = dp(8);

                TextView tv = new TextView(this);
                tv.setText(cq.note + " · " + cq.subject + " (" + cq.topic + ")\nSaved at " + formatSec(cq.elapsedSeconds));
                tv.setTextColor(colInk);
                tv.setTextSize(13);
                row.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

                Button resumeBtn = makeActionButton("Resume", colAcc, Color.WHITE);
                resumeBtn.setOnClickListener(v -> resumeCircledItem(cq));
                row.addView(resumeBtn);
                circledCard.addView(row, rlp);
            }
        }

        // Recent Session Log Card
        LinearLayout recentCard = new LinearLayout(this);
        recentCard.setOrientation(LinearLayout.VERTICAL);
        recentCard.setPadding(dp(18), dp(18), dp(18), dp(18));
        recentCard.setBackground(roundedBox(colSurface, colLine, 20));
        rightCol.addView(recentCard, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        List<QuestionLog> allLogs = db.getAllLogs();
        addSectionHeader(recentCard, "Recent Logged Questions (" + allLogs.size() + " total)");
        if (allLogs.isEmpty()) {
            addMutedText(recentCard, "Solved questions will appear here as you log them.");
        } else {
            int start = Math.max(0, allLogs.size() - 8);
            for (int i = allLogs.size() - 1; i >= start; i--) {
                final QuestionLog q = allLogs.get(i);
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(12), dp(9), dp(12), dp(9));
                row.setBackground(roundedBox(colSub, colLine, 12));
                LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                rlp.topMargin = dp(6);

                boolean solo = "solved".equals(q.outcome) && q.extLookup == 0;
                TextView leftTv = new TextView(this);
                String tagStr = (q.errorTag == null || q.errorTag.isEmpty()) ? "" : " [" + q.errorTag + "]";
                leftTv.setText(q.note + " · " + q.topic + tagStr);
                leftTv.setTextColor(colInk);
                leftTv.setTextSize(13);
                row.addView(leftTv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

                TextView rightTv = new TextView(this);
                rightTv.setText(formatSec(q.secondsSpent) + (solo ? " ✓" : " (Assisted)"));
                rightTv.setTextColor(solo ? colOk : colWarn);
                rightTv.setTypeface(Typeface.DEFAULT_BOLD);
                rightTv.setTextSize(13);
                row.addView(rightTv);

                recentCard.addView(row, rlp);
            }
        }
    }

    private void buildSetupCard(LinearLayout card) {
        addSectionHeader(card, "Start a Study Session");

        // Mode Switcher (Practice Countdown vs Exam Stopwatch)
        LinearLayout modeRow = new LinearLayout(this);
        modeRow.setOrientation(LinearLayout.HORIZONTAL);
        Button learnBtn = makeActionButton(
                "Practice Countdown",
                "learn".equals(studyMode) ? colAcc : colSub,
                "learn".equals(studyMode) ? Color.WHITE : colInk);
        Button testBtn = makeActionButton(
                "Exam Stopwatch",
                "test".equals(studyMode) ? colAcc : colSub,
                "test".equals(studyMode) ? Color.WHITE : colInk);
        learnBtn.setOnClickListener(v -> { studyMode = "learn"; rebuildScreen(); });
        testBtn.setOnClickListener(v -> { studyMode = "test"; rebuildScreen(); });
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        mlp.rightMargin = dp(8);
        modeRow.addView(learnBtn, mlp);
        modeRow.addView(testBtn, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        card.addView(modeRow);

        // Subject Chips
        addLabel(card, "SUBJECT");
        HorizontalScrollView subScroll = new HorizontalScrollView(this);
        LinearLayout subRow = new LinearLayout(this);
        subRow.setOrientation(LinearLayout.HORIZONTAL);
        for (final String sub : db.getSubjects()) {
            boolean on = sub.equals(selectedSubject);
            Button chip = makeActionButton(sub, on ? colAcc : colSub, on ? Color.WHITE : colInk);
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            clp.rightMargin = dp(8);
            chip.setOnClickListener(v -> {
                selectedSubject = sub;
                rebuildScreen();
            });
            subRow.addView(chip, clp);
        }
        subScroll.addView(subRow);
        card.addView(subScroll);

        // Topic Input
        addLabel(card, "TOPIC / CHAPTER / SET");
        final EditText topicEt = makeEditText(currentTopic, "e.g. Definite Integration or Exercise 4B", InputType.TYPE_CLASS_TEXT);
        card.addView(topicEt);

        // Goals Row
        LinearLayout goalsRow = new LinearLayout(this);
        goalsRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams grp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        grp.topMargin = dp(12);
        card.addView(goalsRow, grp);

        final EditText sessGoalEt = makeEditText(String.valueOf(sessionGoal), "Session Qs", InputType.TYPE_CLASS_NUMBER);
        final EditText topGoalEt = makeEditText(String.valueOf(topicGoal), "Topic Goal", InputType.TYPE_CLASS_NUMBER);
        final EditText targetMinEt = makeEditText(String.valueOf(targetSeconds / 60.0), "Target Min", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        glp.rightMargin = dp(8);
        goalsRow.addView(sessGoalEt, glp);
        goalsRow.addView(topGoalEt, glp);
        goalsRow.addView(targetMinEt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        // Companion Coach Tone
        addLabel(card, "COMPANION COACH TONE");
        LinearLayout toneRow = new LinearLayout(this);
        toneRow.setOrientation(LinearLayout.HORIZONTAL);
        String[][] tones = new String[][]{{"off", "Off"}, {"kind", "Kind"}, {"mix", "Mixed"}, {"roast", "Roast"}};
        for (final String[] pair : tones) {
            boolean on = pair[0].equals(coachTone);
            Button tb = makeActionButton(pair[1], on ? colAcc : colSub, on ? Color.WHITE : colInk);
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            tlp.rightMargin = dp(6);
            tb.setOnClickListener(v -> { coachTone = pair[0]; rebuildScreen(); });
            toneRow.addView(tb, tlp);
        }
        card.addView(toneRow);

        Button startBtn = makeActionButton("Start Study Session", colAcc, Color.WHITE);
        startBtn.setTextSize(16);
        startBtn.setPadding(dp(18), dp(16), dp(18), dp(16));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.topMargin = dp(20);
        startBtn.setOnClickListener(v -> {
            String t = topicEt.getText().toString().trim();
            if (t.isEmpty()) t = "General Practice";
            currentTopic = t;
            try { sessionGoal = Integer.parseInt(sessGoalEt.getText().toString().trim()); } catch (Exception ignored) {}
            try { topicGoal = Integer.parseInt(topGoalEt.getText().toString().trim()); } catch (Exception ignored) {}
            try {
                double mins = Double.parseDouble(targetMinEt.getText().toString().trim());
                targetSeconds = Math.max(30, (int) Math.round(mins * 60));
            } catch (Exception ignored) {}

            if (topicGoal > 0) {
                db.saveTopicGoal(selectedSubject, currentTopic, topicGoal, targetSeconds);
            }
            sessionDoneCount = 0;
            goodStreak = 0;
            badStreak = 0;
            undoHistory.clear();
            sessionActive = true;
            startFreshQuestion(1);
            rebuildScreen();
        });
        card.addView(startBtn, slp);
    }

    private void buildLiveTimerCard(LinearLayout card) {
        LinearLayout topMeta = new LinearLayout(this);
        topMeta.setOrientation(LinearLayout.HORIZONTAL);
        TextView subTitle = new TextView(this);
        subTitle.setText(selectedSubject + " · " + currentTopic);
        subTitle.setTextColor(colAcc);
        subTitle.setTypeface(Typeface.DEFAULT_BOLD);
        subTitle.setTextSize(15);
        topMeta.addView(subTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView qCountTv = new TextView(this);
        qCountTv.setText("Question #" + questionNum + "  (" + sessionDoneCount + "/" + sessionGoal + " done)");
        qCountTv.setTextColor(colMute);
        qCountTv.setTypeface(Typeface.DEFAULT_BOLD);
        topMeta.addView(qCountTv);
        card.addView(topMeta);

        // Circular Ring + Big Clock Readout
        FrameLayout ringBox = new FrameLayout(this);
        LinearLayout.LayoutParams rblp = new LinearLayout.LayoutParams(dp(230), dp(230));
        rblp.gravity = Gravity.CENTER_HORIZONTAL;
        rblp.topMargin = dp(12);
        rblp.bottomMargin = dp(12);

        ringTimerView = new RingTimerView(this, colSub, colAcc);
        ringBox.addView(ringTimerView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout centerLabels = new LinearLayout(this);
        centerLabels.setOrientation(LinearLayout.VERTICAL);
        centerLabels.setGravity(Gravity.CENTER);
        clockReadoutText = new TextView(this);
        clockReadoutText.setTextSize(42);
        clockReadoutText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        clockReadoutText.setTextColor(colInk);
        centerLabels.addView(clockReadoutText);

        clockSubtitleText = new TextView(this);
        clockSubtitleText.setTextSize(12);
        clockSubtitleText.setTextColor(colMute);
        centerLabels.addView(clockSubtitleText);

        ringBox.addView(centerLabels, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        card.addView(ringBox, rblp);
        updateLiveClockWidgets();

        // Companion Coach Banner
        if (!"off".equals(coachTone)) {
            coachBannerView = new TextView(this);
            coachBannerView.setText(coachMessage);
            coachBannerView.setTextColor(colInk);
            coachBannerView.setTextSize(13);
            coachBannerView.setPadding(dp(14), dp(10), dp(14), dp(10));
            coachBannerView.setBackground(roundedBox(colSub, colLine, 12));
            LinearLayout.LayoutParams cblp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            cblp.bottomMargin = dp(12);
            card.addView(coachBannerView, cblp);
        }

        // Question Note Input
        liveNoteInput = makeEditText(currentNote, "Optional Question # or note (e.g. Q14 — sign error)", InputType.TYPE_CLASS_TEXT);
        card.addView(liveNoteInput);

        // Mistake / Lookup Reason Chips
        HorizontalScrollView tagScroll = new HorizontalScrollView(this);
        LinearLayout tagRow = new LinearLayout(this);
        tagRow.setOrientation(LinearLayout.HORIZONTAL);
        tagRow.setPadding(0, dp(10), 0, dp(12));
        String[][] tags = new String[][]{
                {"concept", "Concept gap"},
                {"calc", "Calc error"},
                {"formula", "Forgot formula"},
                {"misread", "Misread"},
                {"trick", "Missed shortcut"}
        };
        for (final String[] tg : tags) {
            boolean on = tg[0].equals(selectedErrorTag);
            Button b = makeActionButton(tg[1], on ? colWarn : colSub, on ? Color.BLACK : colInk);
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            tlp.rightMargin = dp(8);
            b.setOnClickListener(v -> {
                currentNote = liveNoteInput.getText().toString();
                selectedErrorTag = on ? "" : tg[0];
                rebuildScreen();
            });
            tagRow.addView(b, tlp);
        }
        tagScroll.addView(tagRow);
        card.addView(tagScroll);

        // Primary Action Row: Pause/Resume + Solved & Next
        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        pauseResumeButton = makeActionButton(timerRunning ? "Pause" : "Resume", colSub, colInk);
        pauseResumeButton.setOnClickListener(v -> togglePause());
        Button solvedBtn = makeActionButton("Solved & Next ✓", colAcc, Color.WHITE);
        solvedBtn.setOnClickListener(v -> logCurrentQuestion("solved"));

        LinearLayout.LayoutParams r1lp = new LinearLayout.LayoutParams(0, dp(54), 1f);
        r1lp.rightMargin = dp(10);
        row1.addView(pauseResumeButton, r1lp);
        row1.addView(solvedBtn, new LinearLayout.LayoutParams(0, dp(54), 1f));
        card.addView(row1);

        // Secondary Action Row: +2m Almost, +2m Looked Up, Circle for Later
        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams r2Wrap = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        r2Wrap.topMargin = dp(10);

        Button almostBtn = makeActionButton("+2m Almost", colSub, colWarn);
        almostBtn.setOnClickListener(v -> {
            extAlmost++;
            beepedCurrent = false;
            updateLiveClockWidgets();
        });
        Button lookupBtn = makeActionButton("+2m Looked Up", colSub, colBad);
        lookupBtn.setOnClickListener(v -> {
            extLookup++;
            beepedCurrent = false;
            updateLiveClockWidgets();
        });
        Button circleBtn = makeActionButton("Circle for Later", colSub, colInk);
        circleBtn.setOnClickListener(v -> logCurrentQuestion("circled"));

        LinearLayout.LayoutParams c3lp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        c3lp.rightMargin = dp(8);
        row2.addView(almostBtn, c3lp);
        row2.addView(lookupBtn, c3lp);
        row2.addView(circleBtn, new LinearLayout.LayoutParams(0, dp(48), 1f));
        card.addView(row2, r2Wrap);

        // Footer Row: Undo Last + End Session
        LinearLayout footer = new LinearLayout(this);
        footer.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        flp.topMargin = dp(14);

        Button undoBtn = makeActionButton("↩ Undo Last", colSub, colMute);
        undoBtn.setOnClickListener(v -> undoLastQuestion());
        Button endBtn = makeActionButton("End Session", colSub, colBad);
        endBtn.setOnClickListener(v -> confirmEndSession());

        footer.addView(undoBtn);
        View spacer = new View(this);
        footer.addView(spacer, new LinearLayout.LayoutParams(0, dp(1), 1f));
        footer.addView(endBtn);
        card.addView(footer, flp);
    }

    private void startFreshQuestion(int num) {
        questionNum = num;
        accumulatedMs = 0L;
        lastResumeRealtimeMs = SystemClock.elapsedRealtime();
        displaySeconds = 0;
        extAlmost = 0;
        extLookup = 0;
        selectedErrorTag = "";
        currentNote = "";
        beepedCurrent = false;
        timerRunning = true;
    }

    private void togglePause() {
        if (!sessionActive) return;
        if (timerRunning) {
            accumulatedMs += SystemClock.elapsedRealtime() - lastResumeRealtimeMs;
            timerRunning = false;
        } else {
            lastResumeRealtimeMs = SystemClock.elapsedRealtime();
            timerRunning = true;
        }
        if (pauseResumeButton != null) {
            pauseResumeButton.setText(timerRunning ? "Pause" : "Resume");
        }
    }

    private void logCurrentQuestion(String outcome) {
        if (liveNoteInput != null) {
            currentNote = liveNoteInput.getText().toString().trim();
        }
        int spent = timerRunning
                ? (int) ((accumulatedMs + (SystemClock.elapsedRealtime() - lastResumeRealtimeMs)) / 1000L)
                : (int) (accumulatedMs / 1000L);
        spent = Math.max(1, spent);
        String noteVal = currentNote.isEmpty() ? ("Q#" + questionNum) : currentNote;

        if ("circled".equals(outcome)) {
            db.insertCircled(new CircledQuestion(
                    0, System.currentTimeMillis(), selectedSubject, currentTopic,
                    questionNum, noteVal, spent, extAlmost, extLookup, targetSeconds, selectedErrorTag
            ));
            coachMessage = "📌 Parked " + noteVal + " in Circled tray (" + formatSec(spent) + " saved).";
            startFreshQuestion(questionNum + 1);
            rebuildScreen();
            return;
        }

        String finalOutcome = extLookup > 0 ? "lookup" : outcome;
        QuestionLog entry = new QuestionLog(
                0, System.currentTimeMillis(), studyMode, selectedSubject, currentTopic,
                noteVal, spent, targetSeconds, extAlmost, extLookup, finalOutcome, selectedErrorTag
        );
        entry.id = db.insertLog(entry);
        undoHistory.add(entry);
        sessionDoneCount++;

        if ("solved".equals(finalOutcome)) {
            goodStreak++;
            badStreak = 0;
        } else {
            badStreak++;
            goodStreak = 0;
        }

        if (sessionGoal > 0 && sessionDoneCount == sessionGoal) {
            playAlertTone(true);
            coachMessage = "🎉 Session goal of " + sessionGoal + " questions complete! Great focus block.";
        } else if ("lookup".equals(finalOutcome)) {
            coachMessage = "roast".equals(coachTone)
                    ? "😏 Answer key doing heavy lifting today! Added to Review Queue."
                    : "🧐 Logged as assisted. Tagged in your Review Queue for a clean retry.";
        } else if (goodStreak >= 3) {
            coachMessage = "🔥 " + goodStreak + " solo solves in a row! Keep that rhythm.";
        } else if (spent <= targetSeconds / 2) {
            coachMessage = "⚡ Speed run! Solved solo in under half your target time.";
        } else {
            coachMessage = "😎 Clean solo solve. Onto the next one.";
        }

        startFreshQuestion(questionNum + 1);
        rebuildScreen();
    }

    private void undoLastQuestion() {
        if (undoHistory.isEmpty()) return;
        QuestionLog last = undoHistory.remove(undoHistory.size() - 1);
        db.deleteLog(last.id);
        sessionDoneCount = Math.max(0, sessionDoneCount - 1);
        startFreshQuestion(Math.max(1, questionNum - 1));
        rebuildScreen();
    }

    private void resumeCircledItem(CircledQuestion cq) {
        db.removeCircled(cq.id);
        selectedSubject = cq.subject;
        currentTopic = cq.topic;
        questionNum = cq.questionNumber;
        currentNote = cq.note;
        accumulatedMs = cq.elapsedSeconds * 1000L;
        lastResumeRealtimeMs = SystemClock.elapsedRealtime();
        displaySeconds = cq.elapsedSeconds;
        extAlmost = cq.extAlmost;
        extLookup = cq.extLookup;
        targetSeconds = cq.targetSeconds;
        selectedErrorTag = cq.errorTag;
        sessionActive = true;
        timerRunning = true;
        currentTab = "studio";
        rebuildScreen();
    }

    private void confirmEndSession() {
        if (displaySeconds >= 5) {
            new AlertDialog.Builder(this)
                    .setTitle("Question Still in Progress")
                    .setMessage("You have spent " + formatSec(displaySeconds) + " on Question #" + questionNum + ". Log it before ending?")
                    .setPositiveButton("Log Solved & End", (d, w) -> {
                        logCurrentQuestion("solved");
                        sessionActive = false;
                        timerRunning = false;
                        currentTab = "stats";
                        rebuildScreen();
                    })
                    .setNeutralButton("Circle & End", (d, w) -> {
                        logCurrentQuestion("circled");
                        sessionActive = false;
                        timerRunning = false;
                        currentTab = "stats";
                        rebuildScreen();
                    })
                    .setNegativeButton("Discard & End", (d, w) -> {
                        sessionActive = false;
                        timerRunning = false;
                        currentTab = "stats";
                        rebuildScreen();
                    })
                    .show();
        } else {
            sessionActive = false;
            timerRunning = false;
            currentTab = "stats";
            rebuildScreen();
        }
    }

    private void buildReviewView(LinearLayout parent) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(22), dp(22), dp(22), dp(22));
        card.setBackground(roundedBox(colSurface, colLine, 20));
        parent.addView(card);

        addSectionHeader(card, "Spaced Review & Retry Queue");
        addMutedText(card, "Resume any circled question from its saved time or launch a clean retry on questions where you needed a lookup.");

        for (final CircledQuestion cq : db.getCircledQueue()) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(14), dp(12), dp(14), dp(12));
            row.setBackground(roundedBox(colSub, colWarn, 14));
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.topMargin = dp(10);

            TextView tv = new TextView(this);
            tv.setText("[CIRCLED] " + cq.subject + " · " + cq.topic + " — " + cq.note + "\nPaused at " + formatSec(cq.elapsedSeconds));
            tv.setTextColor(colInk);
            row.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            Button btn = makeActionButton("Resume Timer", colAcc, Color.WHITE);
            btn.setOnClickListener(v -> resumeCircledItem(cq));
            row.addView(btn);
            card.addView(row, rlp);
        }

        List<QuestionLog> all = db.getAllLogs();
        for (int i = all.size() - 1; i >= 0; i--) {
            final QuestionLog q = all.get(i);
            if (!"lookup".equals(q.outcome) && (q.errorTag == null || q.errorTag.isEmpty())) continue;

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(14), dp(12), dp(14), dp(12));
            row.setBackground(roundedBox(colSub, colLine, 14));
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.topMargin = dp(10);

            TextView tv = new TextView(this);
            String tag = (q.errorTag == null || q.errorTag.isEmpty()) ? "Looked Up" : q.errorTag;
            tv.setText("[" + tag.toUpperCase(Locale.US) + "] " + q.subject + " · " + q.topic + " — " + q.note +
                    "\nSpent " + formatSec(q.secondsSpent) + " (Target " + formatSec(q.targetSeconds) + ")");
            tv.setTextColor(colInk);
            row.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            Button retry = makeActionButton("Retry Clean", colAcc, Color.WHITE);
            retry.setOnClickListener(v -> {
                selectedSubject = q.subject;
                currentTopic = q.topic;
                targetSeconds = q.targetSeconds;
                sessionActive = true;
                startFreshQuestion(1);
                currentNote = q.note + " (Retry)";
                currentTab = "studio";
                rebuildScreen();
            });
            row.addView(retry);
            card.addView(row, rlp);
        }
    }

    private void buildStatsView(LinearLayout parent) {
        List<QuestionLog> logs = db.getAllLogs();
        int n = logs.size();
        int totalSec = 0;
        int soloCnt = 0;
        int overCnt = 0;
        Map<String, int[]> byTopic = new LinkedHashMap<>();

        for (QuestionLog q : logs) {
            totalSec += q.secondsSpent;
            boolean solo = "solved".equals(q.outcome) && q.extLookup == 0;
            if (solo) soloCnt++;
            if (q.secondsSpent > q.targetSeconds) overCnt++;
            String key = q.subject + " · " + q.topic;
            int[] st = byTopic.get(key);
            if (st == null) {
                st = new int[]{0, 0, 0};
                byTopic.put(key, st);
            }
            st[0]++;
            st[1] += q.secondsSpent;
            if (solo) st[2]++;
        }

        LinearLayout kpiRow = new LinearLayout(this);
        kpiRow.setOrientation(LinearLayout.HORIZONTAL);
        parent.addView(kpiRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        int avg = n > 0 ? totalSec / n : 0;
        int soloPct = n > 0 ? Math.round(soloCnt * 100f / n) : 0;
        int onTimePct = n > 0 ? Math.round((n - overCnt) * 100f / n) : 0;

        addKpiCard(kpiRow, "QUESTIONS", String.valueOf(n));
        addKpiCard(kpiRow, "AVG PACE", formatSec(avg));
        addKpiCard(kpiRow, "SOLO RATE", soloPct + "%");
        addKpiCard(kpiRow, "ON TARGET", onTimePct + "%");

        LinearLayout topicCard = new LinearLayout(this);
        topicCard.setOrientation(LinearLayout.VERTICAL);
        topicCard.setPadding(dp(22), dp(22), dp(22), dp(22));
        topicCard.setBackground(roundedBox(colSurface, colLine, 20));
        LinearLayout.LayoutParams tclp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tclp.topMargin = dp(18);
        parent.addView(topicCard, tclp);

        addSectionHeader(topicCard, "Breakdown by Subject & Topic");
        if (byTopic.isEmpty()) {
            addMutedText(topicCard, "No logged questions yet.");
        } else {
            for (Map.Entry<String, int[]> e : byTopic.entrySet()) {
                int[] v = e.getValue();
                int tAvg = v[1] / Math.max(1, v[0]);
                int tSolo = Math.round(v[2] * 100f / Math.max(1, v[0]));
                TextView row = new TextView(this);
                row.setText(e.getKey() + "   —   " + v[0] + " Qs   |   Avg: " + formatSec(tAvg) + "   |   Solo: " + tSolo + "%");
                row.setTextColor(colInk);
                row.setTextSize(14);
                row.setPadding(dp(12), dp(12), dp(12), dp(12));
                row.setBackground(roundedBox(colSub, colLine, 12));
                LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                rlp.topMargin = dp(8);
                topicCard.addView(row, rlp);
            }
        }
    }

    private void addKpiCard(LinearLayout row, String label, String value) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(16), dp(16), dp(16));
        box.setBackground(roundedBox(colSurface, colLine, 16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.rightMargin = dp(10);

        TextView ltv = new TextView(this);
        ltv.setText(label);
        ltv.setTextColor(colMute);
        ltv.setTextSize(11);
        ltv.setTypeface(Typeface.DEFAULT_BOLD);
        box.addView(ltv);

        TextView vtv = new TextView(this);
        vtv.setText(value);
        vtv.setTextColor(colInk);
        vtv.setTextSize(24);
        vtv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        box.addView(vtv);

        row.addView(box, lp);
    }

    private void buildTopicsView(LinearLayout parent) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(22), dp(22), dp(22), dp(22));
        card.setBackground(roundedBox(colSurface, colLine, 20));
        parent.addView(card);

        addSectionHeader(card, "Customize Subjects");
        LinearLayout addRow = new LinearLayout(this);
        addRow.setOrientation(LinearLayout.HORIZONTAL);
        final EditText newSubEt = makeEditText("", "Add custom subject (e.g. Computer Science)", InputType.TYPE_CLASS_TEXT);
        addRow.addView(newSubEt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button addBtn = makeActionButton("Add Subject", colAcc, Color.WHITE);
        addBtn.setOnClickListener(v -> {
            String s = newSubEt.getText().toString().trim();
            if (!s.isEmpty()) {
                db.addSubject(s);
                selectedSubject = s;
                rebuildScreen();
            }
        });
        addRow.addView(addBtn);
        card.addView(addRow);

        for (final String sub : db.getSubjects()) {
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.HORIZONTAL);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(dp(12), dp(10), dp(12), dp(10));
            r.setBackground(roundedBox(colSub, colLine, 12));
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.topMargin = dp(8);

            TextView tv = new TextView(this);
            tv.setText(sub);
            tv.setTextColor(colInk);
            tv.setTextSize(14);
            r.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            if (db.getSubjects().size() > 1) {
                Button del = makeActionButton("Remove", colSub, colBad);
                del.setOnClickListener(v -> {
                    db.removeSubject(sub);
                    rebuildScreen();
                });
                r.addView(del);
            }
            card.addView(r, rlp);
        }
    }

    private void buildSettingsView(LinearLayout parent) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(22), dp(22), dp(22), dp(22));
        card.setBackground(roundedBox(colSurface, colLine, 20));
        parent.addView(card);

        addSectionHeader(card, "Offline Data Backup & Export");
        addMutedText(card, "All study logs, circled questions, and goals are stored offline in SQLite on your Android tablet.");

        Button copyJson = makeActionButton("Copy Full JSON Backup to Clipboard", colAcc, Color.WHITE);
        copyJson.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("FocusPulse JSON Backup", db.exportBackupJson()));
            Toast.makeText(this, "JSON Backup copied to clipboard!", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.topMargin = dp(12);
        card.addView(copyJson, blp);

        Button copyCsv = makeActionButton("Copy Study Log as CSV to Clipboard", colSub, colInk);
        copyCsv.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("FocusPulse CSV", db.buildCsvExport()));
            Toast.makeText(this, "CSV Log copied to clipboard!", Toast.LENGTH_SHORT).show();
        });
        card.addView(copyCsv, blp);

        Button clearBtn = makeActionButton("Clear All Logged Data", colSub, colBad);
        clearBtn.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Delete All Study Data?")
                .setMessage("This will permanently clear your logged questions and circled queue.")
                .setPositiveButton("Delete All", (d, w) -> {
                    db.clearAllData();
                    rebuildScreen();
                })
                .setNegativeButton("Cancel", null)
                .show());
        card.addView(clearBtn, blp);
    }

    private void addSectionHeader(LinearLayout parent, String title) {
        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextColor(colInk);
        tv.setTextSize(16);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(10);
        parent.addView(tv, lp);
    }

    private void addLabel(LinearLayout parent, String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(colMute);
        tv.setTextSize(11);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(14);
        lp.bottomMargin = dp(6);
        parent.addView(tv, lp);
    }

    private void addMutedText(LinearLayout parent, String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(colMute);
        tv.setTextSize(13);
        parent.addView(tv);
    }

    private EditText makeEditText(String initial, String hint, int inputType) {
        EditText et = new EditText(this);
        et.setText(initial);
        et.setHint(hint);
        et.setHintTextColor(colMute);
        et.setTextColor(colInk);
        et.setTextSize(15);
        et.setSingleLine(true);
        et.setInputType(inputType);
        et.setPadding(dp(14), dp(12), dp(14), dp(12));
        et.setBackground(roundedBox(colSub, colLine, 12));
        return et;
    }

    // Custom High-Precision Circular Ring View
    private static class RingTimerView extends View {
        private final Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF arcBounds = new RectF();
        private float progress = 0f;

        public RingTimerView(Context context, int trackColor, int progressColor) {
            super(context);
            float strokePx = TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_DIP, 10, context.getResources().getDisplayMetrics());
            bgPaint.setStyle(Paint.Style.STROKE);
            bgPaint.setStrokeWidth(strokePx);
            bgPaint.setColor(trackColor);

            fgPaint.setStyle(Paint.Style.STROKE);
            fgPaint.setStrokeWidth(strokePx);
            fgPaint.setStrokeCap(Paint.Cap.ROUND);
            fgPaint.setColor(progressColor);
        }

        public void setProgress(float ratio, int color) {
            this.progress = Math.max(0f, Math.min(1f, ratio));
            this.fgPaint.setColor(color);
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float pad = fgPaint.getStrokeWidth();
            arcBounds.set(pad, pad, getWidth() - pad, getHeight() - pad);
            canvas.drawOval(arcBounds, bgPaint);
            canvas.drawArc(arcBounds, -90f, 360f * progress, false, fgPaint);
        }
    }
}
