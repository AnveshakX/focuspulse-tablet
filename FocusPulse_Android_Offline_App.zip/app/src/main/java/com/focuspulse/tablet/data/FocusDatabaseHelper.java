package com.focuspulse.tablet.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class FocusDatabaseHelper extends SQLiteOpenHelper {

    public static class QuestionLog {
        public long id;
        public long timestamp;
        public String mode;
        public String subject;
        public String topic;
        public String note;
        public int secondsSpent;
        public int targetSeconds;
        public int extAlmost;
        public int extLookup;
        public String outcome;
        public String errorTag;

        public QuestionLog(long id, long timestamp, String mode, String subject, String topic,
                           String note, int secondsSpent, int targetSeconds, int extAlmost,
                           int extLookup, String outcome, String errorTag) {
            this.id = id;
            this.timestamp = timestamp;
            this.mode = mode;
            this.subject = subject;
            this.topic = topic;
            this.note = note;
            this.secondsSpent = secondsSpent;
            this.targetSeconds = targetSeconds;
            this.extAlmost = extAlmost;
            this.extLookup = extLookup;
            this.outcome = outcome;
            this.errorTag = errorTag;
        }
    }

    public static class CircledQuestion {
        public long id;
        public long timestamp;
        public String subject;
        public String topic;
        public int questionNumber;
        public String note;
        public int elapsedSeconds;
        public int extAlmost;
        public int extLookup;
        public int targetSeconds;
        public String errorTag;

        public CircledQuestion(long id, long timestamp, String subject, String topic,
                               int questionNumber, String note, int elapsedSeconds,
                               int extAlmost, int extLookup, int targetSeconds, String errorTag) {
            this.id = id;
            this.timestamp = timestamp;
            this.subject = subject;
            this.topic = topic;
            this.questionNumber = questionNumber;
            this.note = note;
            this.elapsedSeconds = elapsedSeconds;
            this.extAlmost = extAlmost;
            this.extLookup = extLookup;
            this.targetSeconds = targetSeconds;
            this.errorTag = errorTag;
        }
    }

    public static class TopicGoal {
        public String subject;
        public String topic;
        public int goalQuestions;
        public int targetSeconds;

        public TopicGoal(String subject, String topic, int goalQuestions, int targetSeconds) {
            this.subject = subject;
            this.topic = topic;
            this.goalQuestions = goalQuestions;
            this.targetSeconds = targetSeconds;
        }
    }

    public FocusDatabaseHelper(Context context) {
        super(context, "focuspulse_offline.db", null, 2);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE question_logs (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "timestamp INTEGER NOT NULL," +
                "mode TEXT NOT NULL," +
                "subject TEXT NOT NULL," +
                "topic TEXT NOT NULL," +
                "note TEXT NOT NULL," +
                "seconds_spent INTEGER NOT NULL," +
                "target_seconds INTEGER NOT NULL," +
                "ext_almost INTEGER NOT NULL," +
                "ext_lookup INTEGER NOT NULL," +
                "outcome TEXT NOT NULL," +
                "error_tag TEXT NOT NULL)");

        db.execSQL("CREATE TABLE circled_queue (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "timestamp INTEGER NOT NULL," +
                "subject TEXT NOT NULL," +
                "topic TEXT NOT NULL," +
                "question_number INTEGER NOT NULL," +
                "note TEXT NOT NULL," +
                "elapsed_seconds INTEGER NOT NULL," +
                "ext_almost INTEGER NOT NULL," +
                "ext_lookup INTEGER NOT NULL," +
                "target_seconds INTEGER NOT NULL," +
                "error_tag TEXT NOT NULL)");

        db.execSQL("CREATE TABLE topic_goals (" +
                "topic_key TEXT PRIMARY KEY," +
                "subject TEXT NOT NULL," +
                "topic TEXT NOT NULL," +
                "goal_questions INTEGER NOT NULL," +
                "target_seconds INTEGER NOT NULL)");

        db.execSQL("CREATE TABLE subjects (" +
                "name TEXT PRIMARY KEY," +
                "sort_order INTEGER NOT NULL)");

        String[] defaults = new String[]{"Mathematics", "Physics", "Chemistry", "General Study"};
        for (int i = 0; i < defaults.length; i++) {
            ContentValues cv = new ContentValues();
            cv.put("name", defaults[i]);
            cv.put("sort_order", i);
            db.insert("subjects", null, cv);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS question_logs");
        db.execSQL("DROP TABLE IF EXISTS circled_queue");
        db.execSQL("DROP TABLE IF EXISTS topic_goals");
        db.execSQL("DROP TABLE IF EXISTS subjects");
        onCreate(db);
    }

    public static String normalizeKey(String subject, String topic) {
        String s = (subject == null ? "general" : subject.trim().toLowerCase(Locale.US));
        String t = (topic == null ? "general" : topic.trim().toLowerCase(Locale.US));
        return s + "|" + t;
    }

    public long insertLog(QuestionLog log) {
        ContentValues cv = new ContentValues();
        cv.put("timestamp", log.timestamp);
        cv.put("mode", log.mode);
        cv.put("subject", log.subject.trim());
        cv.put("topic", log.topic.trim());
        cv.put("note", log.note.trim());
        cv.put("seconds_spent", log.secondsSpent);
        cv.put("target_seconds", log.targetSeconds);
        cv.put("ext_almost", log.extAlmost);
        cv.put("ext_lookup", log.extLookup);
        cv.put("outcome", log.outcome);
        cv.put("error_tag", log.errorTag);
        return getWritableDatabase().insert("question_logs", null, cv);
    }

    public void deleteLog(long id) {
        getWritableDatabase().delete("question_logs", "id = ?", new String[]{String.valueOf(id)});
    }

    public List<QuestionLog> getAllLogs() {
        List<QuestionLog> list = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery("SELECT * FROM question_logs ORDER BY timestamp ASC", null);
        try {
            while (c.moveToNext()) {
                list.add(new QuestionLog(
                        c.getLong(c.getColumnIndexOrThrow("id")),
                        c.getLong(c.getColumnIndexOrThrow("timestamp")),
                        c.getString(c.getColumnIndexOrThrow("mode")),
                        c.getString(c.getColumnIndexOrThrow("subject")),
                        c.getString(c.getColumnIndexOrThrow("topic")),
                        c.getString(c.getColumnIndexOrThrow("note")),
                        c.getInt(c.getColumnIndexOrThrow("seconds_spent")),
                        c.getInt(c.getColumnIndexOrThrow("target_seconds")),
                        c.getInt(c.getColumnIndexOrThrow("ext_almost")),
                        c.getInt(c.getColumnIndexOrThrow("ext_lookup")),
                        c.getString(c.getColumnIndexOrThrow("outcome")),
                        c.getString(c.getColumnIndexOrThrow("error_tag"))
                ));
            }
        } finally {
            c.close();
        }
        return list;
    }

    public long insertCircled(CircledQuestion item) {
        ContentValues cv = new ContentValues();
        cv.put("timestamp", item.timestamp);
        cv.put("subject", item.subject.trim());
        cv.put("topic", item.topic.trim());
        cv.put("question_number", item.questionNumber);
        cv.put("note", item.note.trim());
        cv.put("elapsed_seconds", item.elapsedSeconds);
        cv.put("ext_almost", item.extAlmost);
        cv.put("ext_lookup", item.extLookup);
        cv.put("target_seconds", item.targetSeconds);
        cv.put("error_tag", item.errorTag);
        return getWritableDatabase().insert("circled_queue", null, cv);
    }

    public void removeCircled(long id) {
        getWritableDatabase().delete("circled_queue", "id = ?", new String[]{String.valueOf(id)});
    }

    public List<CircledQuestion> getCircledQueue() {
        List<CircledQuestion> list = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery("SELECT * FROM circled_queue ORDER BY timestamp DESC", null);
        try {
            while (c.moveToNext()) {
                list.add(new CircledQuestion(
                        c.getLong(c.getColumnIndexOrThrow("id")),
                        c.getLong(c.getColumnIndexOrThrow("timestamp")),
                        c.getString(c.getColumnIndexOrThrow("subject")),
                        c.getString(c.getColumnIndexOrThrow("topic")),
                        c.getInt(c.getColumnIndexOrThrow("question_number")),
                        c.getString(c.getColumnIndexOrThrow("note")),
                        c.getInt(c.getColumnIndexOrThrow("elapsed_seconds")),
                        c.getInt(c.getColumnIndexOrThrow("ext_almost")),
                        c.getInt(c.getColumnIndexOrThrow("ext_lookup")),
                        c.getInt(c.getColumnIndexOrThrow("target_seconds")),
                        c.getString(c.getColumnIndexOrThrow("error_tag"))
                ));
            }
        } finally {
            c.close();
        }
        return list;
    }

    public void saveTopicGoal(String subject, String topic, int goalQuestions, int targetSeconds) {
        ContentValues cv = new ContentValues();
        cv.put("topic_key", normalizeKey(subject, topic));
        cv.put("subject", subject.trim());
        cv.put("topic", topic.trim());
        cv.put("goal_questions", goalQuestions);
        cv.put("target_seconds", targetSeconds);
        getWritableDatabase().insertWithOnConflict("topic_goals", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public Map<String, TopicGoal> getTopicGoals() {
        Map<String, TopicGoal> map = new LinkedHashMap<>();
        Cursor c = getReadableDatabase().rawQuery("SELECT * FROM topic_goals", null);
        try {
            while (c.moveToNext()) {
                String k = c.getString(c.getColumnIndexOrThrow("topic_key"));
                map.put(k, new TopicGoal(
                        c.getString(c.getColumnIndexOrThrow("subject")),
                        c.getString(c.getColumnIndexOrThrow("topic")),
                        c.getInt(c.getColumnIndexOrThrow("goal_questions")),
                        c.getInt(c.getColumnIndexOrThrow("target_seconds"))
                ));
            }
        } finally {
            c.close();
        }
        return map;
    }

    public List<String> getSubjects() {
        List<String> list = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery("SELECT name FROM subjects ORDER BY sort_order ASC", null);
        try {
            while (c.moveToNext()) {
                list.add(c.getString(0));
            }
        } finally {
            c.close();
        }
        if (list.isEmpty()) {
            list.add("Mathematics");
            list.add("Physics");
            list.add("Chemistry");
        }
        return list;
    }

    public void addSubject(String name) {
        if (name == null || name.trim().isEmpty()) return;
        ContentValues cv = new ContentValues();
        cv.put("name", name.trim());
        cv.put("sort_order", getSubjects().size());
        getWritableDatabase().insertWithOnConflict("subjects", null, cv, SQLiteDatabase.CONFLICT_IGNORE);
    }

    public void removeSubject(String name) {
        if (getSubjects().size() > 1) {
            getWritableDatabase().delete("subjects", "name = ?", new String[]{name});
        }
    }

    public void clearAllData() {
        SQLiteDatabase db = getWritableDatabase();
        db.delete("question_logs", null, null);
        db.delete("circled_queue", null, null);
    }

    public String exportBackupJson() {
        try {
            JSONObject root = new JSONObject();
            root.put("version", 2);
            JSONArray arr = new JSONArray();
            for (QuestionLog q : getAllLogs()) {
                JSONObject o = new JSONObject();
                o.put("t", q.timestamp);
                o.put("m", q.mode);
                o.put("sub", q.subject);
                o.put("ch", q.topic);
                o.put("note", q.note);
                o.put("s", q.secondsSpent);
                o.put("tg", q.targetSeconds);
                o.put("a", q.extAlmost);
                o.put("b", q.extLookup);
                o.put("r", q.outcome);
                o.put("tag", q.errorTag);
                arr.put(o);
            }
            root.put("log", arr);
            return root.toString(2);
        } catch (Exception e) {
            return "{}";
        }
    }

    public String buildCsvExport() {
        StringBuilder sb = new StringBuilder();
        sb.append("date,mode,subject,topic,note,seconds,target_seconds,plus_almost,plus_lookup,outcome,error_tag\n");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
        for (QuestionLog q : getAllLogs()) {
            sb.append(csvCell(sdf.format(new Date(q.timestamp)))).append(",");
            sb.append(csvCell(q.mode)).append(",");
            sb.append(csvCell(q.subject)).append(",");
            sb.append(csvCell(q.topic)).append(",");
            sb.append(csvCell(q.note)).append(",");
            sb.append(q.secondsSpent).append(",");
            sb.append(q.targetSeconds).append(",");
            sb.append(q.extAlmost).append(",");
            sb.append(q.extLookup).append(",");
            sb.append(csvCell(q.outcome)).append(",");
            sb.append(csvCell(q.errorTag)).append("\n");
        }
        return sb.toString();
    }

    private String csvCell(String val) {
        if (val == null) val = "";
        return "\"" + val.replace("\"", "\"\"") + "\"";
    }
}
