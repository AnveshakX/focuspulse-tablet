plugins {
    id("com.android.application")
}

android {
    namespace = "com.focuspulse.tablet"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.focuspulse.tablet"
        minSdk = 24
        targetSdk = 34
        versionCode = 3
        versionName = "3.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    // Zero external dependencies: 100% pure Android SDK for fast, deterministic builds
}
